// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef CERTS_H
#define CERTS_H

#ifdef __cplusplus
extern "C"
{
#endif

	extern const char certificates[];

#ifdef __cplusplus
}
#endif

#endif /* CERTS_H */
